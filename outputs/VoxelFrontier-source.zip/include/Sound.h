#pragma once

#include <cstdint>
#include <vector>

class SoundSystem {
public:
    SoundSystem();

    void playFootstep() const;
    void playBreak() const;
    void playPlace() const;
    void playDamage() const;
    void playSplash() const;
    void setMasterVolume(float value);

private:
    std::vector<std::uint8_t> footstep_;
    std::vector<std::uint8_t> break_;
    std::vector<std::uint8_t> place_;
    std::vector<std::uint8_t> damage_;
    std::vector<std::uint8_t> splash_;
    float masterVolume_ = 1.0f;

    static std::vector<std::uint8_t> createSound(float frequency, float duration,
                                                  float noiseAmount, std::uint32_t seed, float volume = 1.0f);
    static void play(const std::vector<std::uint8_t>& sound, float volume);
};

