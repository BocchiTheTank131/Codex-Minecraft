#include "Renderer.h"

#include "World.h"

#include <glm/gtc/matrix_inverse.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/constants.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <cctype>
#include <cstdint>
#include <fstream>
#include <random>
#include <stdexcept>
#include <string>
#include <unordered_map>

namespace {
constexpr const char* WorldVertexShader = R"GLSL(
#version 330 core
layout(location=0) in vec3 aPosition;
layout(location=1) in vec2 aUv;
layout(location=2) in vec3 aNormal;
layout(location=3) in float aSunLight;
layout(location=4) in float aBlockLight;
layout(location=5) in float aAo;
uniform mat4 uView;
uniform mat4 uProjection;
out vec2 vUv;
out vec3 vNormal;
out float vSunLight;
out float vBlockLight;
out float vAo;
out float vDistance;
void main() {
    vec4 viewPosition = uView * vec4(aPosition, 1.0);
    gl_Position = uProjection * viewPosition;
    vUv = aUv; vNormal = aNormal;
    vSunLight = aSunLight; vBlockLight = aBlockLight; vAo = aAo;
    vDistance = length(viewPosition.xyz);
}
)GLSL";

constexpr const char* WorldFragmentShader = R"GLSL(
#version 330 core
in vec2 vUv;
in vec3 vNormal;
in float vSunLight;
in float vBlockLight;
in float vAo;
in float vDistance;
uniform sampler2D uAtlas;
uniform vec3 uSunDirection;
uniform vec3 uSkyColor;
uniform float uDaylight;
uniform bool uWaterPass;
uniform bool uFullbright;
uniform bool uUnderwater;
out vec4 fragColor;
void main() {
    vec4 texel = texture(uAtlas, vUv);
    if (texel.a < 0.20) discard;
    float sunDiffuse = max(dot(normalize(vNormal), uSunDirection), 0.0);
    float moonDiffuse = max(dot(normalize(vNormal), -uSunDirection), 0.0);
    float directional = sunDiffuse * (0.18 + 0.48 * uDaylight) + moonDiffuse * 0.10 * (1.0-uDaylight);
    float skyContribution = vSunLight * mix(0.035, 0.46, uDaylight);
    float directionalContribution = vSunLight * directional;
    float emittedContribution = vBlockLight * 0.88;
    float brightness = 0.018 + vAo * (skyContribution + directionalContribution + emittedContribution);
    vec3 lit = uFullbright ? texel.rgb : texel.rgb * brightness + vec3(1.0,0.54,0.18) * vBlockLight * 0.13;
    if (uWaterPass) lit = mix(lit, vec3(0.07,0.26,0.47), 0.28);
    float fogStart = uUnderwater ? 3.0 : mix(75.0, 105.0, uDaylight);
    float fog = smoothstep(fogStart, uUnderwater ? 24.0 : fogStart + 65.0, vDistance);
    vec3 fogColor = uUnderwater ? vec3(0.025,0.18,0.30) : uSkyColor;
    fragColor = vec4(mix(lit, fogColor, fog), uWaterPass ? texel.a * 0.68 : texel.a);
}
)GLSL";

constexpr const char* SkyVertexShader = R"GLSL(
#version 330 core
out vec2 vNdc;
void main() {
    vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
    vNdc = p * 2.0 - 1.0;
    gl_Position = vec4(vNdc, 1.0, 1.0);
}
)GLSL";

constexpr const char* SkyFragmentShader = R"GLSL(
#version 330 core
in vec2 vNdc;
uniform mat4 uInverseViewProjection;
uniform vec3 uSunDirection;
uniform float uDaylight;
uniform float uTime;
out vec4 fragColor;
float hash(vec3 p) {
    p = fract(p * 0.1031); p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}
float valueNoise(vec2 p) {
    vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
    float a=hash(vec3(i,7.0)), b=hash(vec3(i+vec2(1,0),7.0));
    float c=hash(vec3(i+vec2(0,1),7.0)), d=hash(vec3(i+vec2(1,1),7.0));
    return mix(mix(a,b,f.x),mix(c,d,f.x),f.y);
}
float cloudNoise(vec2 p) {
    float value=0.0, amplitude=0.55;
    for(int i=0;i<4;i++){ value+=valueNoise(p)*amplitude; p=p*2.03+17.1; amplitude*=0.5; }
    return value;
}
void main() {
    vec4 farPoint = uInverseViewProjection * vec4(vNdc, 1.0, 1.0);
    vec3 ray = normalize(farPoint.xyz / farPoint.w);
    float horizon = clamp(ray.y * 0.55 + 0.45, 0.0, 1.0);
    vec3 nightHorizon = vec3(0.025,0.035,0.075);
    vec3 nightZenith = vec3(0.005,0.008,0.025);
    vec3 dayHorizon = vec3(0.58,0.76,0.94);
    vec3 dayZenith = vec3(0.22,0.48,0.82);
    vec3 color = mix(mix(nightHorizon, nightZenith, horizon),
                     mix(dayHorizon, dayZenith, horizon), uDaylight);
    float twilight = (1.0-uDaylight) * smoothstep(-0.28,0.05,uSunDirection.y);
    color += vec3(0.42,0.10,0.035) * twilight * pow(1.0-horizon,2.0);
    float twinkle = 0.72 + 0.28*sin(uTime*2.0 + hash(floor(ray*520.0))*40.0);
    float star = step(0.9962, hash(floor(ray * 520.0))) * (1.0-uDaylight) * smoothstep(-0.12,0.18,ray.y) * twinkle;
    color += vec3(star);
    if(ray.y > 0.025) {
        vec2 cloudUv = ray.xz / (ray.y + 0.22) * 1.8 + vec2(uTime*0.012, uTime*0.002);
        float clouds = smoothstep(0.54,0.68,cloudNoise(cloudUv));
        clouds *= smoothstep(0.02,0.16,ray.y) * (0.18 + 0.82*uDaylight);
        color = mix(color, mix(vec3(0.16,0.18,0.24),vec3(0.96,0.97,1.0),uDaylight), clouds*0.72);
    }
    float sun = smoothstep(0.9987, 0.99965, dot(ray, uSunDirection));
    float glow = pow(max(dot(ray, uSunDirection), 0.0), 96.0);
    color += vec3(1.0,0.78,0.38) * (sun * 1.5 + glow * 0.32) * uDaylight;
    float moonDot=dot(ray,-uSunDirection);
    float moon = smoothstep(0.9989,0.99972,moonDot);
    float phaseCut = smoothstep(0.9990,0.99974,dot(normalize(ray+vec3(0.018,0.0,0.0)),-uSunDirection));
    color += vec3(0.70,0.78,0.94) * max(moon-phaseCut*0.46,0.0) * (1.0-uDaylight);
    fragColor = vec4(color,1.0);
}
)GLSL";

constexpr const char* EntityVertexShader = R"GLSL(
#version 330 core
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aNormal;
uniform mat4 uModel;
uniform mat4 uView;
uniform mat4 uProjection;
out vec3 vNormal;
void main(){ gl_Position=uProjection*uView*uModel*vec4(aPosition,1.0); vNormal=mat3(uModel)*aNormal; }
)GLSL";
constexpr const char* EntityFragmentShader = R"GLSL(
#version 330 core
in vec3 vNormal;
uniform vec3 uColor;
uniform vec3 uSunDirection;
uniform float uDaylight;
out vec4 fragColor;
void main(){
    float diffuse=max(dot(normalize(vNormal),uSunDirection),0.0);
    float light=mix(0.16,0.62,uDaylight)+diffuse*0.32*uDaylight;
    fragColor=vec4(uColor*light,1.0);
}
)GLSL";
constexpr const char* UiVertexShader = R"GLSL(
#version 330 core
layout(location=0) in vec2 aPosition;
layout(location=1) in vec4 aColor;
layout(location=2) in vec2 aUv;
layout(location=3) in float aTextured;
out vec4 vColor; out vec2 vUv; out float vTextured;
void main(){ gl_Position=vec4(aPosition,0.0,1.0); vColor=aColor; vUv=aUv; vTextured=aTextured; }
)GLSL";
constexpr const char* UiFragmentShader = R"GLSL(
#version 330 core
in vec4 vColor; in vec2 vUv; in float vTextured; uniform sampler2D uItemAtlas; out vec4 fragColor;
void main(){ vec4 sprite=texture(uItemAtlas,vUv); fragColor=mix(vColor,sprite*vColor,clamp(vTextured,0.0,1.0)); if(fragColor.a<0.02)discard; }
)GLSL";

constexpr const char* ItemVertexShader = R"GLSL(
#version 330 core
layout(location=0) in vec3 aPosition; layout(location=1) in vec2 aUv;
uniform mat4 uView; uniform mat4 uProjection; out vec2 vUv;
void main(){gl_Position=uProjection*uView*vec4(aPosition,1.0);vUv=aUv;}
)GLSL";
constexpr const char* ItemFragmentShader = R"GLSL(
#version 330 core
in vec2 vUv; uniform sampler2D uItemAtlas; out vec4 fragColor;
void main(){vec4 c=texture(uItemAtlas,vUv);if(c.a<0.12)discard;fragColor=vec4(c.rgb,c.a);}
)GLSL";
constexpr const char* ParticleVertexShader = R"GLSL(
#version 330 core
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aColor;
uniform mat4 uView; uniform mat4 uProjection;
out vec3 vColor;
void main(){
    vec4 viewPos=uView*vec4(aPosition,1.0);
    gl_Position=uProjection*viewPos;
    gl_PointSize=clamp(55.0/max(-viewPos.z,1.0),2.0,7.0);
    vColor=aColor;
}
)GLSL";
constexpr const char* ParticleFragmentShader = R"GLSL(
#version 330 core
in vec3 vColor; out vec4 fragColor;
void main(){ fragColor=vec4(vColor,1.0); }
)GLSL";

struct UiVertex { glm::vec2 position; glm::vec4 color; glm::vec2 uv; float textured; };
struct ParticleVertex { glm::vec3 position; glm::vec3 color; };
struct EntityVertex { glm::vec3 position; glm::vec3 normal; };

struct CelestialState {
    glm::vec3 sunDirection;
    glm::vec3 skyColor;
    float daylight;
};

CelestialState celestial(float worldTime) {
    constexpr float cycleSeconds = 210.0f;
    const float angle = worldTime / cycleSeconds * glm::two_pi<float>() + 0.35f;
    const glm::vec3 sun = glm::normalize(glm::vec3(std::cos(angle) * 0.72f, std::sin(angle), -0.42f));
    const float daylight = glm::smoothstep(-0.13f, 0.17f, sun.y);
    return {sun, glm::mix(glm::vec3(0.025f,0.035f,0.075f), glm::vec3(0.50f,0.72f,0.93f), daylight), daylight};
}

std::uint8_t hashPixel(int x, int y, int seed) {
    std::uint32_t n = static_cast<std::uint32_t>(x * 374761393 + y * 668265263 + seed * 2246822519U);
    n = (n ^ (n >> 13U)) * 1274126177U;
    return static_cast<std::uint8_t>((n ^ (n >> 16U)) & 0xffU);
}

void putPixel(std::vector<std::uint8_t>& pixels, int width, int x, int y,
              int r, int g, int b, int a=255) {
    const std::size_t i=static_cast<std::size_t>((y*width+x)*4);
    pixels[i]=static_cast<std::uint8_t>(std::clamp(r,0,255));
    pixels[i+1]=static_cast<std::uint8_t>(std::clamp(g,0,255));
    pixels[i+2]=static_cast<std::uint8_t>(std::clamp(b,0,255));
    pixels[i+3]=static_cast<std::uint8_t>(std::clamp(a,0,255));
}

void addRect(std::vector<UiVertex>& vertices, float x, float y, float w, float h,
             const glm::vec4& color, int screenWidth, int screenHeight) {
    auto ndc=[&](float px,float py){ return glm::vec2(px/screenWidth*2.0f-1.0f, 1.0f-py/screenHeight*2.0f); };
    const glm::vec2 a=ndc(x,y), b=ndc(x+w,y), c=ndc(x+w,y+h), d=ndc(x,y+h);
    vertices.insert(vertices.end(),{{a,color,{0,0},0},{b,color,{0,0},0},{c,color,{0,0},0},{a,color,{0,0},0},{c,color,{0,0},0},{d,color,{0,0},0}});
}

const std::array<std::uint8_t,7>& glyph(char c) {
    static const std::array<std::uint8_t,7> blank{};
    static const std::unordered_map<char,std::array<std::uint8_t,7>> font={
        {'A',{14,17,17,31,17,17,17}},{'B',{30,17,17,30,17,17,30}},
        {'C',{14,17,16,16,16,17,14}},{'D',{30,17,17,17,17,17,30}},
        {'E',{31,16,16,30,16,16,31}},{'F',{31,16,16,30,16,16,16}},
        {'G',{14,17,16,23,17,17,15}},{'H',{17,17,17,31,17,17,17}},
        {'I',{14,4,4,4,4,4,14}},{'J',{7,2,2,2,18,18,12}},
        {'K',{17,18,20,24,20,18,17}},{'L',{16,16,16,16,16,16,31}},
        {'M',{17,27,21,21,17,17,17}},{'N',{17,25,21,19,17,17,17}},
        {'O',{14,17,17,17,17,17,14}},{'P',{30,17,17,30,16,16,16}},
        {'Q',{14,17,17,17,21,18,13}},{'R',{30,17,17,30,20,18,17}},
        {'S',{15,16,16,14,1,1,30}},{'T',{31,4,4,4,4,4,4}},
        {'U',{17,17,17,17,17,17,14}},{'V',{17,17,17,17,17,10,4}},
        {'W',{17,17,17,21,21,21,10}},{'X',{17,17,10,4,10,17,17}},
        {'Y',{17,17,10,4,4,4,4}},{'Z',{31,1,2,4,8,16,31}},
        {'0',{14,17,19,21,25,17,14}},{'1',{4,12,4,4,4,4,14}},
        {'2',{14,17,1,2,4,8,31}},{'3',{30,1,1,14,1,1,30}},
        {'4',{2,6,10,18,31,2,2}},{'5',{31,16,16,30,1,1,30}},
        {'6',{14,16,16,30,17,17,14}},{'7',{31,1,2,4,8,8,8}},
        {'8',{14,17,17,14,17,17,14}},{'9',{14,17,17,15,1,1,14}},
        {'-',{0,0,0,31,0,0,0}},{'.',{0,0,0,0,0,12,12}},{':',{0,12,12,0,12,12,0}},
        {'/',{1,2,2,4,8,8,16}},{'+',{0,4,4,31,4,4,0}},{' ',{0,0,0,0,0,0,0}}
    };
    const auto found=font.find(c); return found==font.end()?blank:found->second;
}

int itemSpriteIndex(Item item){switch(item){case Item::Grass:return 0;case Item::Dirt:return 1;case Item::Stone:return 2;case Item::Sand:return 3;case Item::Log:return 4;case Item::Leaves:return 5;case Item::Water:return 6;case Item::CoalOre:return 7;case Item::IronOre:return 8;case Item::GoldOre:return 9;case Item::CopperOre:return 10;case Item::DiamondOre:return 11;case Item::Planks:return 12;case Item::Stick:return 13;case Item::CraftingTable:return 14;case Item::Torch:return 15;case Item::Seeds:return 16;case Item::Wheat:return 17;case Item::Bread:return 18;case Item::RawMeat:return 19;case Item::WoodPickaxe:return 20;case Item::StonePickaxe:return 21;case Item::IronPickaxe:return 22;case Item::WoodAxe:return 23;case Item::StoneAxe:return 24;case Item::IronAxe:return 25;case Item::WoodShovel:return 26;case Item::StoneShovel:return 27;case Item::IronShovel:return 28;default:return -1;}}
void addSprite(std::vector<UiVertex>&v,Item item,float x,float y,float w,float h,const glm::vec4&color,int W,int H){int index=itemSpriteIndex(item);if(index<0)return;int col=index%6,row=index/6;float u0=col/6.f,v0=row/5.f,u1=(col+1)/6.f,v1=(row+1)/5.f;auto ndc=[&](float px,float py){return glm::vec2(px/W*2.f-1.f,1.f-py/H*2.f);};glm::vec2 a=ndc(x,y),b=ndc(x+w,y),c=ndc(x+w,y+h),d=ndc(x,y+h);v.insert(v.end(),{{a,color,{u0,v0},1},{b,color,{u1,v0},1},{c,color,{u1,v1},1},{a,color,{u0,v0},1},{c,color,{u1,v1},1},{d,color,{u0,v1},1}});}
glm::vec3 blockColor(Block block) {
    switch(block){
        case Block::Grass:return {0.30f,0.67f,0.20f}; case Block::Dirt:return {0.48f,0.31f,0.17f};
        case Block::Stone:return {0.50f,0.50f,0.52f}; case Block::Sand:return {0.82f,0.75f,0.47f};
        case Block::Log:return {0.42f,0.26f,0.12f}; case Block::Leaves:return {0.16f,0.48f,0.13f};
        case Block::Water:return {0.10f,0.38f,0.72f}; case Block::CoalOre:return {0.18f,0.18f,0.20f};
        case Block::IronOre:return {0.72f,0.44f,0.27f}; case Block::GoldOre:return {0.92f,0.70f,0.12f}; default:return {0.8f,0.8f,0.8f};
    }
}
}

Renderer::Renderer() {
    auto makeProgram=[&](const char* vs,const char* fs){ GLuint v=compileShader(GL_VERTEX_SHADER,vs),f=compileShader(GL_FRAGMENT_SHADER,fs); GLuint p=linkProgram(v,f); glDeleteShader(v);glDeleteShader(f);return p;};
    worldProgram_=makeProgram(WorldVertexShader,WorldFragmentShader);
    skyProgram_=makeProgram(SkyVertexShader,SkyFragmentShader);
    uiProgram_=makeProgram(UiVertexShader,UiFragmentShader);
    particleProgram_=makeProgram(ParticleVertexShader,ParticleFragmentShader);
    entityProgram_=makeProgram(EntityVertexShader,EntityFragmentShader);
    itemProgram_=makeProgram(ItemVertexShader,ItemFragmentShader);
    atlasTexture_=createAtlasTexture();
    itemTexture_=loadItemTexture("assets/item_icons.rgba");
    glGenVertexArrays(1,&skyVao_);
    glGenVertexArrays(1,&uiVao_); glGenBuffers(1,&uiVbo_);
    glBindVertexArray(uiVao_); glBindBuffer(GL_ARRAY_BUFFER,uiVbo_);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,sizeof(UiVertex),reinterpret_cast<void*>(offsetof(UiVertex,position)));
    glEnableVertexAttribArray(1); glVertexAttribPointer(1,4,GL_FLOAT,GL_FALSE,sizeof(UiVertex),reinterpret_cast<void*>(offsetof(UiVertex,color)));
    glEnableVertexAttribArray(2); glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(UiVertex),reinterpret_cast<void*>(offsetof(UiVertex,uv)));
    glEnableVertexAttribArray(3); glVertexAttribPointer(3,1,GL_FLOAT,GL_FALSE,sizeof(UiVertex),reinterpret_cast<void*>(offsetof(UiVertex,textured)));
    glGenVertexArrays(1,&particleVao_); glGenBuffers(1,&particleVbo_);
    glBindVertexArray(particleVao_); glBindBuffer(GL_ARRAY_BUFFER,particleVbo_);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(ParticleVertex),reinterpret_cast<void*>(offsetof(ParticleVertex,position)));
    glEnableVertexAttribArray(1); glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(ParticleVertex),reinterpret_cast<void*>(offsetof(ParticleVertex,color)));
    const glm::vec3 normals[6]={{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
    const glm::vec3 corners[6][4]={
        {{.5f,-.5f,-.5f},{.5f,.5f,-.5f},{.5f,.5f,.5f},{.5f,-.5f,.5f}},
        {{-.5f,-.5f,.5f},{-.5f,.5f,.5f},{-.5f,.5f,-.5f},{-.5f,-.5f,-.5f}},
        {{-.5f,.5f,.5f},{.5f,.5f,.5f},{.5f,.5f,-.5f},{-.5f,.5f,-.5f}},
        {{-.5f,-.5f,-.5f},{.5f,-.5f,-.5f},{.5f,-.5f,.5f},{-.5f,-.5f,.5f}},
        {{.5f,-.5f,.5f},{.5f,.5f,.5f},{-.5f,.5f,.5f},{-.5f,-.5f,.5f}},
        {{-.5f,-.5f,-.5f},{-.5f,.5f,-.5f},{.5f,.5f,-.5f},{.5f,-.5f,-.5f}}};
    const int indices[6]={0,1,2,0,2,3};std::vector<EntityVertex> cube;cube.reserve(36);
    for(int face=0;face<6;++face)for(int index:indices)cube.push_back({corners[face][index],normals[face]});
    glGenVertexArrays(1,&entityVao_);glGenBuffers(1,&entityVbo_);glBindVertexArray(entityVao_);glBindBuffer(GL_ARRAY_BUFFER,entityVbo_);
    glBufferData(GL_ARRAY_BUFFER,static_cast<GLsizeiptr>(cube.size()*sizeof(EntityVertex)),cube.data(),GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(EntityVertex),reinterpret_cast<void*>(offsetof(EntityVertex,position)));
    glEnableVertexAttribArray(1);glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(EntityVertex),reinterpret_cast<void*>(offsetof(EntityVertex,normal)));
    glBindVertexArray(0);
    glGenVertexArrays(1,&itemVao_);glGenBuffers(1,&itemVbo_);glBindVertexArray(itemVao_);glBindBuffer(GL_ARRAY_BUFFER,itemVbo_);glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,5*sizeof(float),(void*)0);glEnableVertexAttribArray(1);glVertexAttribPointer(1,2,GL_FLOAT,GL_FALSE,5*sizeof(float),(void*)(3*sizeof(float)));glBindVertexArray(0);
}

Renderer::~Renderer(){
    if(itemVbo_)glDeleteBuffers(1,&itemVbo_);if(itemVao_)glDeleteVertexArrays(1,&itemVao_);
    if(entityVbo_)glDeleteBuffers(1,&entityVbo_);if(entityVao_)glDeleteVertexArrays(1,&entityVao_);
    if(particleVbo_)glDeleteBuffers(1,&particleVbo_);if(particleVao_)glDeleteVertexArrays(1,&particleVao_);
    if(uiVbo_)glDeleteBuffers(1,&uiVbo_);if(uiVao_)glDeleteVertexArrays(1,&uiVao_);if(skyVao_)glDeleteVertexArrays(1,&skyVao_);
    if(itemTexture_)glDeleteTextures(1,&itemTexture_);if(atlasTexture_)glDeleteTextures(1,&atlasTexture_);if(itemProgram_)glDeleteProgram(itemProgram_);if(entityProgram_)glDeleteProgram(entityProgram_);if(particleProgram_)glDeleteProgram(particleProgram_);
    if(uiProgram_)glDeleteProgram(uiProgram_);if(skyProgram_)glDeleteProgram(skyProgram_);if(worldProgram_)glDeleteProgram(worldProgram_);
}

GLuint Renderer::compileShader(GLenum type,const char* source){
    GLuint shader=glCreateShader(type);glShaderSource(shader,1,&source,nullptr);glCompileShader(shader);GLint ok=GL_FALSE;glGetShaderiv(shader,GL_COMPILE_STATUS,&ok);
    if(!ok){GLint n=0;glGetShaderiv(shader,GL_INFO_LOG_LENGTH,&n);std::string log(static_cast<std::size_t>(n),'\0');glGetShaderInfoLog(shader,n,nullptr,log.data());glDeleteShader(shader);throw std::runtime_error("Shader compilation failed: "+log);}return shader;
}
GLuint Renderer::linkProgram(GLuint v,GLuint f){GLuint p=glCreateProgram();glAttachShader(p,v);glAttachShader(p,f);glLinkProgram(p);GLint ok=GL_FALSE;glGetProgramiv(p,GL_LINK_STATUS,&ok);if(!ok){GLint n=0;glGetProgramiv(p,GL_INFO_LOG_LENGTH,&n);std::string log(static_cast<std::size_t>(n),'\0');glGetProgramInfoLog(p,n,nullptr,log.data());glDeleteProgram(p);throw std::runtime_error("Shader linking failed: "+log);}return p;}

GLuint Renderer::createAtlasTexture(){
    constexpr int s=16,count=17,width=s*count;std::vector<std::uint8_t> p(static_cast<std::size_t>(width*s*4));
    for(int y=0;y<s;++y)for(int x=0;x<s;++x){
        int g=static_cast<int>(hashPixel(x,y,11)%31)-15,d=static_cast<int>(hashPixel(x,y,29)%35)-17,st=static_cast<int>(hashPixel(x,y,53)%39)-19;
        putPixel(p,width,x,y,static_cast<std::uint8_t>(78+g/3),static_cast<std::uint8_t>(150+g),static_cast<std::uint8_t>(57+g/3));
        if(y<4)putPixel(p,width,s+x,y,72+g/3,143+g,52+g/3);else putPixel(p,width,s+x,y,126+d,86+d/2,52+d/3);
        putPixel(p,width,2*s+x,y,126+d,86+d/2,52+d/3);putPixel(p,width,3*s+x,y,126+st,126+st,128+st);
        int sn=static_cast<int>(hashPixel(x,y,71)%25)-12;putPixel(p,width,4*s+x,y,211+sn,194+sn,126+sn/2);
        int wn=static_cast<int>(hashPixel(x,y,83)%25)-12;putPixel(p,width,5*s+x,y,111+wn,72+wn/2,35+wn/3);
        int dx=x-7,dy=y-7,r=static_cast<int>(std::sqrt(static_cast<float>(dx*dx+dy*dy))*7);putPixel(p,width,6*s+x,y,139-r,96-r,48-r/2);
        int ln=static_cast<int>(hashPixel(x,y,97)%35)-17;bool hole=hashPixel(x,y,101)>242;putPixel(p,width,7*s+x,y,45+ln/3,121+ln,38+ln/3,hole?0:255);
        int wave=((x+y/2)%5==0)?25:0;putPixel(p,width,8*s+x,y,35+wave,105+wave,190+wave,170);
        bool coalFleck=hashPixel(x,y,131)>210;putPixel(p,width,9*s+x,y,coalFleck?38:126+st,coalFleck?38:126+st,coalFleck?42:128+st);
        bool ironFleck=hashPixel(x,y,149)>216;putPixel(p,width,10*s+x,y,ironFleck?188:126+st,ironFleck?125:126+st,ironFleck?82:128+st);
        bool goldFleck=hashPixel(x,y,167)>222;putPixel(p,width,11*s+x,y,goldFleck?238:126+st,goldFleck?190:126+st,goldFleck?42:128+st);
        bool copperFleck=hashPixel(x,y,179)>216;putPixel(p,width,12*s+x,y,copperFleck?198:126+st,copperFleck?91:126+st,copperFleck?43:128+st);
        bool diamondFleck=hashPixel(x,y,191)>226;putPixel(p,width,13*s+x,y,diamondFleck?54:126+st,diamondFleck?222:126+st,diamondFleck?226:128+st);
        int plankLine=(y%5==0)?-24:0;putPixel(p,width,14*s+x,y,174+plankLine+d/4,116+plankLine+d/5,55+plankLine/2);
        bool tableGrid=(x%8==0||y%8==0);putPixel(p,width,15*s+x,y,tableGrid?72:145+d/5,tableGrid?42:86+d/6,tableGrid?20:39);
        bool flame=(y<6&&x>4&&x<11);putPixel(p,width,16*s+x,y,flame?255:105+wn/3,flame?178:67+wn/4,flame?34:28);
    }
    GLuint t=0;glGenTextures(1,&t);glBindTexture(GL_TEXTURE_2D,t);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,width,s,0,GL_RGBA,GL_UNSIGNED_BYTE,p.data());
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);return t;
}

GLuint Renderer::loadItemTexture(const std::string& path){std::ifstream input(path,std::ios::binary);if(!input)throw std::runtime_error("Missing item atlas: "+path);std::int32_t width=0,height=0;input.read(reinterpret_cast<char*>(&width),4);input.read(reinterpret_cast<char*>(&height),4);if(!input||width<=0||height<=0||width>4096||height>4096)throw std::runtime_error("Invalid item atlas");std::vector<std::uint8_t> pixels(static_cast<std::size_t>(width*height*4));input.read(reinterpret_cast<char*>(pixels.data()),static_cast<std::streamsize>(pixels.size()));if(!input)throw std::runtime_error("Truncated item atlas");GLuint texture=0;glGenTextures(1,&texture);glBindTexture(GL_TEXTURE_2D,texture);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data());glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);return texture;}
void Renderer::renderSky(const glm::mat4& view,const glm::mat4& projection,float worldTime)const{
    const CelestialState state=celestial(worldTime);glm::mat4 rotationView=glm::mat4(glm::mat3(view));glm::mat4 inverse=glm::inverse(projection*rotationView);
    glDisable(GL_DEPTH_TEST);glUseProgram(skyProgram_);glUniformMatrix4fv(glGetUniformLocation(skyProgram_,"uInverseViewProjection"),1,GL_FALSE,glm::value_ptr(inverse));
    glUniform3fv(glGetUniformLocation(skyProgram_,"uSunDirection"),1,glm::value_ptr(state.sunDirection));glUniform1f(glGetUniformLocation(skyProgram_,"uDaylight"),state.daylight);glUniform1f(glGetUniformLocation(skyProgram_,"uTime"),worldTime);glBindVertexArray(skyVao_);glDrawArrays(GL_TRIANGLES,0,3);glEnable(GL_DEPTH_TEST);
}

void Renderer::renderWorld(const World& world,const glm::mat4& view,const glm::mat4& projection,const glm::vec3& camera,float worldTime,bool fullbright,bool underwater)const{
    const CelestialState state=celestial(worldTime);const glm::mat4 vp=projection*view;glUseProgram(worldProgram_);
    glUniformMatrix4fv(glGetUniformLocation(worldProgram_,"uView"),1,GL_FALSE,glm::value_ptr(view));glUniformMatrix4fv(glGetUniformLocation(worldProgram_,"uProjection"),1,GL_FALSE,glm::value_ptr(projection));
    glUniform3fv(glGetUniformLocation(worldProgram_,"uSunDirection"),1,glm::value_ptr(state.sunDirection));glUniform3fv(glGetUniformLocation(worldProgram_,"uSkyColor"),1,glm::value_ptr(state.skyColor));glUniform1f(glGetUniformLocation(worldProgram_,"uDaylight"),state.daylight);glUniform1i(glGetUniformLocation(worldProgram_,"uFullbright"),fullbright?GL_TRUE:GL_FALSE);glUniform1i(glGetUniformLocation(worldProgram_,"uUnderwater"),underwater?GL_TRUE:GL_FALSE);
    glActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,atlasTexture_);glUniform1i(glGetUniformLocation(worldProgram_,"uAtlas"),0);glUniform1i(glGetUniformLocation(worldProgram_,"uWaterPass"),GL_FALSE);world.drawOpaque(vp);
    glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glDepthMask(GL_FALSE);glUniform1i(glGetUniformLocation(worldProgram_,"uWaterPass"),GL_TRUE);world.drawWater(vp,camera);glDepthMask(GL_TRUE);glDisable(GL_BLEND);
}

void Renderer::spawnBreakParticles(const glm::ivec3& blockPosition,Block block){
    static std::mt19937 rng(424242);std::uniform_real_distribution<float> random(-1.0f,1.0f);const glm::vec3 color=blockColor(block);
    for(int i=0;i<18;++i){glm::vec3 velocity(random(rng)*2.2f,1.4f+std::abs(random(rng))*2.2f,random(rng)*2.2f);particles_.push_back({glm::vec3(blockPosition)+glm::vec3(0.5f)+glm::vec3(random(rng),random(rng),random(rng))*0.32f,velocity,color,0.65f+std::abs(random(rng))*0.35f});}
}
void Renderer::updateParticles(float dt){for(Particle& p:particles_){p.life-=dt;p.velocity.y-=10.0f*dt;p.position+=p.velocity*dt;}particles_.erase(std::remove_if(particles_.begin(),particles_.end(),[](const Particle& p){return p.life<=0.0f;}),particles_.end());}
void Renderer::renderParticles(const glm::mat4& view,const glm::mat4& projection)const{
    if(particles_.empty())return;std::vector<ParticleVertex> vertices;vertices.reserve(particles_.size());for(const Particle& p:particles_)vertices.push_back({p.position,p.color*std::min(1.0f,p.life*2.0f)});
    glBindBuffer(GL_ARRAY_BUFFER,particleVbo_);glBufferData(GL_ARRAY_BUFFER,static_cast<GLsizeiptr>(vertices.size()*sizeof(ParticleVertex)),vertices.data(),GL_STREAM_DRAW);glUseProgram(particleProgram_);glUniformMatrix4fv(glGetUniformLocation(particleProgram_,"uView"),1,GL_FALSE,glm::value_ptr(view));glUniformMatrix4fv(glGetUniformLocation(particleProgram_,"uProjection"),1,GL_FALSE,glm::value_ptr(projection));glEnable(GL_PROGRAM_POINT_SIZE);glBindVertexArray(particleVao_);glDrawArrays(GL_POINTS,0,static_cast<GLsizei>(vertices.size()));glBindVertexArray(0);
}

void Renderer::renderEntities(const std::vector<RenderCuboid>& cuboids,const glm::mat4& view,
                              const glm::mat4& projection,float worldTime)const{
    if(cuboids.empty())return;const CelestialState state=celestial(worldTime);glUseProgram(entityProgram_);
    glUniformMatrix4fv(glGetUniformLocation(entityProgram_,"uView"),1,GL_FALSE,glm::value_ptr(view));
    glUniformMatrix4fv(glGetUniformLocation(entityProgram_,"uProjection"),1,GL_FALSE,glm::value_ptr(projection));
    glUniform3fv(glGetUniformLocation(entityProgram_,"uSunDirection"),1,glm::value_ptr(state.sunDirection));
    glUniform1f(glGetUniformLocation(entityProgram_,"uDaylight"),state.daylight);glBindVertexArray(entityVao_);
    for(const RenderCuboid& cuboid:cuboids){glm::mat4 model=glm::translate(glm::mat4(1.0f),cuboid.center);model=glm::scale(model,cuboid.size);
        glUniformMatrix4fv(glGetUniformLocation(entityProgram_,"uModel"),1,GL_FALSE,glm::value_ptr(model));
        glUniform3fv(glGetUniformLocation(entityProgram_,"uColor"),1,glm::value_ptr(cuboid.color));glDrawArrays(GL_TRIANGLES,0,36);}
    glBindVertexArray(0);
}
void Renderer::renderHud(int width,int height,const Inventory& inventory,float health,float hurtFlash,
                         float breakProgress,const std::string& debugText,const std::string& craftingText)const{
    std::vector<UiVertex> vertices;
    auto drawText=[&](const std::string& text,float originX,float originY,float scale,const glm::vec4& color){
        float px=originX,py=originY;for(char raw:text){char c=static_cast<char>(std::toupper(static_cast<unsigned char>(raw)));
            if(c=='\n'){px=originX;py+=9.0f*scale;continue;}const auto& rows=glyph(c);
            for(int row=0;row<7;++row)for(int col=0;col<5;++col)if(rows[static_cast<std::size_t>(row)]&(1<<(4-col)))
                addRect(vertices,px+col*scale,py+row*scale,scale,scale,color,width,height);px+=6.0f*scale;}
    };
    if(hurtFlash>0.0f)addRect(vertices,0,0,static_cast<float>(width),static_cast<float>(height),{0.72f,0.02f,0.01f,std::min(0.24f,hurtFlash*0.65f)},width,height);
    const float slot=44.0f,gap=4.0f,total=9*slot+8*gap,start=(width-total)*0.5f,y=height-58.0f;
    for(int i=0;i<9;++i){const float x=start+i*(slot+gap);const ItemStack& stack=inventory.slot(i);const Item item=stack.item;const int count=stack.count;
        if(i==inventory.selectedSlot())addRect(vertices,x-3,y-3,slot+6,slot+6,{0.95f,0.95f,0.95f,0.98f},width,height);
        addRect(vertices,x,y,slot,slot,{0.06f,0.06f,0.08f,0.86f},width,height);addRect(vertices,x+3,y+3,slot-6,slot-6,{0.22f,0.22f,0.25f,0.90f},width,height);
        if(count>0)addSprite(vertices,item,x+4,y+4,36,36,{1,1,1,1},width,height);
        drawText(std::to_string(i+1),x+4,y+4,1.0f,{0.78f,0.80f,0.84f,1});
        if(count>0)drawText(std::to_string(count),x+slot-4-static_cast<float>(std::to_string(count).size())*6.0f,y+slot-10,1.0f,{1,1,1,1});
    }
    const float healthX=start,healthY=y-20.0f;for(int i=0;i<10;++i){const float filled=std::clamp(health-static_cast<float>(i*2),0.0f,2.0f)/2.0f;
        addRect(vertices,healthX+i*18,healthY,14,11,{0.16f,0.03f,0.04f,0.90f},width,height);if(filled>0)addRect(vertices,healthX+i*18+2,healthY+2,10*filled,7,{0.86f,0.08f,0.10f,1},width,height);}
    addRect(vertices,width*0.5f-10,height*0.5f-1,20,2,{1,1,1,0.95f},width,height);addRect(vertices,width*0.5f-1,height*0.5f-10,2,20,{1,1,1,0.95f},width,height);
    if(breakProgress>0.0f){addRect(vertices,width*0.5f-37,height*0.5f+18,74,8,{0,0,0,0.72f},width,height);addRect(vertices,width*0.5f-35,height*0.5f+20,70*std::clamp(breakProgress,0.0f,1.0f),4,{0.92f,0.78f,0.30f,1},width,height);}
    if(!debugText.empty()){int lines=1,maxChars=0,current=0;for(char c:debugText){if(c=='\n'){++lines;maxChars=std::max(maxChars,current);current=0;}else ++current;}maxChars=std::max(maxChars,current);
        addRect(vertices,8,8,static_cast<float>(maxChars*12+12),static_cast<float>(lines*18+10),{0,0,0,0.62f},width,height);drawText(debugText,14,14,2.0f,{0.92f,0.96f,1.0f,1});}
    if(!craftingText.empty()){const float panelW=std::min(680.0f,static_cast<float>(width)-32.0f),panelX=(width-panelW)*0.5f,panelY=y-72.0f;
        addRect(vertices,panelX,panelY,panelW,54,{0.04f,0.03f,0.025f,0.88f},width,height);drawText(craftingText,panelX+12,panelY+9,1.5f,{0.98f,0.86f,0.58f,1});}
    glBindBuffer(GL_ARRAY_BUFFER,uiVbo_);glBufferData(GL_ARRAY_BUFFER,static_cast<GLsizeiptr>(vertices.size()*sizeof(UiVertex)),vertices.data(),GL_STREAM_DRAW);
    glDisable(GL_DEPTH_TEST);glDisable(GL_CULL_FACE);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glUseProgram(uiProgram_);glActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,itemTexture_);glUniform1i(glGetUniformLocation(uiProgram_,"uItemAtlas"),0);glBindVertexArray(uiVao_);
    glDrawArrays(GL_TRIANGLES,0,static_cast<GLsizei>(vertices.size()));glBindVertexArray(0);glDisable(GL_BLEND);glEnable(GL_CULL_FACE);glEnable(GL_DEPTH_TEST);
}
void Renderer::renderItemSprites(const std::vector<RenderItemSprite>& sprites,const glm::mat4& view,const glm::mat4& projection,float time)const{
 if(sprites.empty())return;glm::mat4 inv=glm::inverse(view);glm::vec3 right=glm::normalize(glm::vec3(inv[0])),up=glm::normalize(glm::vec3(inv[1]));std::vector<float> vertices;vertices.reserve(sprites.size()*30);
 auto push=[&](glm::vec3 p,float u,float v){vertices.insert(vertices.end(),{p.x,p.y,p.z,u,v});};
 for(const auto&s:sprites){int n=itemSpriteIndex(s.item);if(n<0)continue;int col=n%6,row=n/6;float u0=col/6.f,v0=row/5.f,u1=(col+1)/6.f,v1=(row+1)/5.f;glm::vec3 c=s.center+glm::vec3(0,.12f+std::sin(time*2.7f+s.center.x)*.05f,0);float h=s.size*.5f;glm::vec3 a=c-right*h+up*h,b=c-right*h-up*h,d=c+right*h+up*h,e=c+right*h-up*h;push(a,u0,v0);push(b,u0,v1);push(e,u1,v1);push(a,u0,v0);push(e,u1,v1);push(d,u1,v0);}
 glBindBuffer(GL_ARRAY_BUFFER,itemVbo_);glBufferData(GL_ARRAY_BUFFER,static_cast<GLsizeiptr>(vertices.size()*sizeof(float)),vertices.data(),GL_STREAM_DRAW);glUseProgram(itemProgram_);glUniformMatrix4fv(glGetUniformLocation(itemProgram_,"uView"),1,GL_FALSE,glm::value_ptr(view));glUniformMatrix4fv(glGetUniformLocation(itemProgram_,"uProjection"),1,GL_FALSE,glm::value_ptr(projection));glActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,itemTexture_);glUniform1i(glGetUniformLocation(itemProgram_,"uItemAtlas"),0);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glBindVertexArray(itemVao_);glDrawArrays(GL_TRIANGLES,0,static_cast<GLsizei>(vertices.size()/5));glBindVertexArray(0);glDisable(GL_BLEND);
}
void Renderer::renderSelectionOutline(const glm::ivec3& block,const glm::mat4& view,const glm::mat4& projection)const{glUseProgram(entityProgram_);glm::mat4 model=glm::translate(glm::mat4(1),glm::vec3(block)+glm::vec3(.5f));model=glm::scale(model,glm::vec3(1.006f));glUniformMatrix4fv(glGetUniformLocation(entityProgram_,"uModel"),1,GL_FALSE,glm::value_ptr(model));glUniformMatrix4fv(glGetUniformLocation(entityProgram_,"uView"),1,GL_FALSE,glm::value_ptr(view));glUniformMatrix4fv(glGetUniformLocation(entityProgram_,"uProjection"),1,GL_FALSE,glm::value_ptr(projection));glm::vec3 color(.03f);glm::vec3 sun(0,1,0);glUniform3fv(glGetUniformLocation(entityProgram_,"uColor"),1,glm::value_ptr(color));glUniform3fv(glGetUniformLocation(entityProgram_,"uSunDirection"),1,glm::value_ptr(sun));glUniform1f(glGetUniformLocation(entityProgram_,"uDaylight"),1);glBindVertexArray(entityVao_);glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);glLineWidth(2);glDrawArrays(GL_TRIANGLES,0,36);glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);glBindVertexArray(0);}
void Renderer::renderMenu(int width,int height,bool settingsPage,int hovered,const GameSettings&s)const{std::vector<UiVertex>v;auto text=[&](std::string value,float x,float y,float scale,glm::vec4 color){for(char raw:value){char c=static_cast<char>(std::toupper(static_cast<unsigned char>(raw)));const auto&rows=glyph(c);for(int row=0;row<7;++row)for(int col=0;col<5;++col)if(rows[row]&(1<<(4-col)))addRect(v,x+col*scale,y+row*scale,scale,scale,color,width,height);x+=6*scale;}};addRect(v,0,0,static_cast<float>(width),static_cast<float>(height),{0,0,0,.62f},width,height);float panelX=width*.5f-220,panelY=height*.5f-270;addRect(v,panelX,panelY,440,540,{.075f,.075f,.085f,.98f},width,height);text(settingsPage?"SETTINGS":"GAME PAUSED",panelX+(settingsPage?114:92),panelY+28,3,{1,.92f,.68f,1});if(!settingsPage){const char* labels[]={"RESUME GAME","SETTINGS","SAVE WORLD","SAVE & QUIT","EXIT GAME"};for(int i=0;i<5;++i){float y=panelY+100+i*68;addRect(v,panelX+45,y,350,48,i==hovered?glm::vec4(.38f,.48f,.30f,1):glm::vec4(.20f,.20f,.23f,1),width,height);text(labels[i],panelX+75,y+15,2,{1,1,1,1});}}else{std::string values[]={"RENDER DISTANCE  "+std::to_string(s.renderDistance),"FOV  "+std::to_string(static_cast<int>(s.fov)),"MOUSE SENSITIVITY  "+std::to_string(static_cast<int>(s.mouseSensitivity*100)),"MASTER VOLUME  "+std::to_string(static_cast<int>(s.masterVolume*100)),std::string("FULLSCREEN  ")+(s.fullscreen?"ON":"OFF"),std::string("VSYNC  ")+(s.vsync?"ON":"OFF"),std::string("SHOW FPS  ")+(s.showFps?"ON":"OFF"),std::string("SHOW COORDINATES  ")+(s.showCoordinates?"ON":"OFF")};for(int i=0;i<8;++i){float y=panelY+78+i*49;addRect(v,panelX+24,y,392,38,i==hovered?glm::vec4(.35f,.44f,.29f,1):glm::vec4(.19f,.19f,.22f,1),width,height);text(values[i],panelX+38,y+12,1.5f,{1,1,1,1});}float y=panelY+478;addRect(v,panelX+95,y,250,42,hovered==8?glm::vec4(.38f,.48f,.30f,1):glm::vec4(.20f,.20f,.23f,1),width,height);text("BACK",panelX+180,y+13,2,{1,1,1,1});}glBindBuffer(GL_ARRAY_BUFFER,uiVbo_);glBufferData(GL_ARRAY_BUFFER,static_cast<GLsizeiptr>(v.size()*sizeof(UiVertex)),v.data(),GL_STREAM_DRAW);glDisable(GL_DEPTH_TEST);glDisable(GL_CULL_FACE);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glUseProgram(uiProgram_);glActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,itemTexture_);glUniform1i(glGetUniformLocation(uiProgram_,"uItemAtlas"),0);glBindVertexArray(uiVao_);glDrawArrays(GL_TRIANGLES,0,static_cast<GLsizei>(v.size()));glBindVertexArray(0);glDisable(GL_BLEND);glEnable(GL_CULL_FACE);glEnable(GL_DEPTH_TEST);}